import requests
from bs4 import BeautifulSoup

def crawl_page(url):
    response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    soup = BeautifulSoup(response.text, "html.parser")
    links = [a["href"] for a in soup.find_all("a", href=True)]
    print("Link ditemukan:", links)

def run():
    url = input("Masukkan URL: ")
    crawl_page(url)