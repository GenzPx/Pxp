import requests

def whois_lookup(domain):
    response = requests.get(f"https://api.hackertarget.com/whois/?q={domain}")
    print(response.text)

def run():
    target = input("Masukkan domain: ")
    whois_lookup(target)