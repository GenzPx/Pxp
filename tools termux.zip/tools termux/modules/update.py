import os

def check_update():
    print("🔄 Mengecek update...")
    os.system("git pull origin main")
    print("✅ Update selesai!")

def run():
    check_update()