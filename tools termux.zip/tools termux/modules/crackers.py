import hashlib
from concurrent.futures import ThreadPoolExecutor

def crack_hash(hash_value, wordlist):
    with open(wordlist, "r") as file:
        words = file.readlines()
    
    def check_password(word):
        word = word.strip()
        if hashlib.md5(word.encode()).hexdigest() == hash_value:
            print(f"Password ditemukan: {word}")
            return True
        return False

    with ThreadPoolExecutor(max_workers=5) as executor:
        results = executor.map(check_password, words)
        if any(results):
            return

    print("Password tidak ditemukan!")

def run():
    hash_value = input("Masukkan hash MD5: ")
    wordlist = input("Masukkan path wordlist: ")
    crack_hash(hash_value, wordlist)