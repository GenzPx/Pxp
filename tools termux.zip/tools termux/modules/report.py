def generate_report():
    print("📊 Membuat laporan hasil scan...")
    # Simpan hasil dalam file atau database