import hashlib
import random

PASSWORD_HASH = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd6823a1e2c3b4ef3ec"

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def generate_otp():
    return str(random.randint(100000, 999999))

def login():
    password = input("Masukkan password tim: ")
    if hash_password(password) == PASSWORD_HASH:
        otp = generate_otp()
        print(f"OTP: {otp}")  # Simulasi OTP (Bisa dikembangkan dengan email/SMS)
        user_otp = input("Masukkan OTP: ")
        if user_otp == otp:
            print("Login sukses!")
            return True
    print("Autentikasi gagal!")
    return False